export class User {
    userName: string;
    password: string;
    name: string;
    phone: string;
    email: string;
    constructor() {
    }
}